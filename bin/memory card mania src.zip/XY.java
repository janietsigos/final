
public class XY {

	
	private int x,y;
	
	public XY(int xv, int yv) {
		x=xv;
		y=yv;
	}

	public int getX() {
		// TODO Auto-generated method stub
		return x;
	}
	
	public int getY() {
		// TODO Auto-generated method stub
		return y;
	}
	
	
}
