
public class Pics {

	private String [] wordList;
	
	public Pics() {
		wordList = new String[16];
		wordList[0] = "candy1.jpg";
		wordList[1] = "candy1.jpg";
		wordList[2] = "candy2.jpg";
		wordList[3] = "candy2.jpg";
		wordList[4] = "candy3.jpg";
		wordList[5] = "candy3.jpg";
		wordList[6] = "candy4.jpg";
		wordList[7] = "candy4.jpg";
		wordList[8] = "candy5.jpg";
		wordList[9] = "candy5.jpg";
		wordList[10] = "candy6.jfif";
		wordList[11] = "candy6.jfif";
		wordList[12] = "candy7.jfif";
		wordList[13] = "candy7.jfif";
		wordList[14] = "candy8.jfif";
		wordList[15] = "candy8.jfif";

	}
	
	public String [] getPics() {
		
		return wordList;
	}
}